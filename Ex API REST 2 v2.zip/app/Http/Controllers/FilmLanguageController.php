<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Film;
use App\Models\Language;
use App\Http\Resources\FilmResource;

class FilmLanguageController extends Controller
{
    public function show($id, $filmId)
    {
        $language = Language::find($id);
        return new FilmResource($language->films[$filmId-1]);
    }
    public function index($id)
    {
        $language = Language::find($id);
        return FilmResource::collection($language->films);
    }
}
