<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Language;
use App\Http\Resources\LanguageResource;

class LanguageController extends Controller
{
    public function show($id)
    {
        return new LanguageResource(Language::find($id));
    }
    public function index()
    {
        return LanguageResource::collection(Language::all());
    }
}
