<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Film;
use App\Http\Resources\FilmResource;

class FilmController extends Controller
{
    public function show($id)
    {
        return new FilmResource(Film::find($id));
    }
    public function index()
    {
        return FilmResource::collection(Film::all());
    }
}
