INSERT INTO `languages` (`id`, `name`) VALUES
(1, 'English'),
(2, 'French'),
(3, 'Spanish');
