<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Film;

class FilmController extends Controller
{
    public function show($id)
    {
        return Film::find($id);
    }
    public function index()
    {
        return Film::all();
    }
}
