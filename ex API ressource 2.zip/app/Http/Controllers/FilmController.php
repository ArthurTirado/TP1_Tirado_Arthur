<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Film;
use App\Http\Resources\FilmResource;
use Illuminate\Support\Facades\Validator;

class FilmController extends Controller
{
    public function show($id)
    {
        try{
            return (new FilmResource(Film::findOrFail($id)))->response()->setStatusCode(200);
            
        }
    
        catch(Exception $ex)
        {
            abort(500, 'Server error');
        }
    }
    public function index()
    {
        try{
            return FilmResource::collection(Film::paginate(10))->response()->setStatusCode(200);
        }
    
        catch(Exception $ex)
        {
            abort(500, 'Server error');
        }
    }
    public function store(Request $request){
        $film = Film::create($request->all());
        return (new FilmRessource($song))->response()->setStatusCode(201);
    }

    public function delete($id)
    {
        try{
            $film = Film::findOrFail($id);
            $film->delete();
            abort(204, 'No Content');
        }
        catch(Exception $ex){
        }
        abort(500, 'Server error');
    }
    public function averageRentalRate($language_id)
    {
        try {
            $avg = Film::where('language_id', $language_id)->avg('rental_rate');
            return response()->json(['average_rental_rate' => $avg])->setStatusCode(200);
        } 
        
        catch (Exception $ex) {
            abort(500, 'Server error');
        }
    }
}
